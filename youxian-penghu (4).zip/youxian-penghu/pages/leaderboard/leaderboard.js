const app = getApp();
const { REGIONS } = require('../../utils/regions');

Page({
  data: {
    currentTab: 0,
    tabs: ['总积分榜', '地区榜', '闯关榜', '人机榜'],
    globalRank: [],
    regionRank: [],
    levelRank: [],
    battleRank: [],
    userRegion: '',
    userRank: '-'
  },

  onLoad() {
    this.loadRanks();
  },

  onShow() {
    this.loadRanks();
  },

  onTabChange(e) {
    this.setData({ currentTab: e.currentTarget.dataset.idx });
  },

  loadRanks() {
    const region = app.globalData.region;
    this.setData({ userRegion: region ? region.fullName : '未选择' });

    // 从本地存储加载排名数据（实际项目应使用云数据库）
    try {
      const history = wx.getStorageSync('quiz_history') || [];
      const battleHistory = wx.getStorageSync('battle_history') || [];

      // 模拟排行榜数据
      const mockUsers = this.generateMockRanks();

      // 加入当前用户
      const userEntry = {
        name: '我',
        region: region ? region.fullName : '未选择',
        score: app.globalData.totalScore,
        level: app.globalData.currentLevel,
        isUser: true
      };

      // 总积分榜
      let globalRank = [...mockUsers, userEntry].sort((a, b) => b.score - a.score);
      globalRank = globalRank.map((item, idx) => ({
        ...item,
        rank: idx + 1,
        rankIcon: idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : ''
      }));

      // 地区榜
      let regionRank = globalRank.filter(r => r.region === (region ? region.fullName : ''));
      if (regionRank.length === 0) regionRank = [{ ...userEntry, rank: 1, rankIcon: '' }];

      // 闯关榜
      let levelRank = [...mockUsers, userEntry].sort((a, b) => b.level - a.level);
      levelRank = levelRank.map((item, idx) => ({
        ...item,
        rank: idx + 1,
        rankIcon: idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : ''
      }));

      // 人机榜
      const battleScores = battleHistory.reduce((acc, h) => {
        const key = '我';
        if (!acc[key]) acc[key] = { score: 0, wins: 0, total: 0 };
        acc[key].score += h.playerScore;
        acc[key].wins += h.result === 'win' ? 1 : 0;
        acc[key].total += 1;
        return acc;
      }, {});
      const battleRank = Object.entries(battleScores).map(([name, data], idx) => ({
        name, ...data, rank: idx + 1, isUser: true,
        winRate: data.total > 0 ? Math.round(data.wins / data.total * 100) : 0
      }));
      if (battleRank.length === 0) battleRank.push({ name: '我', score: 0, wins: 0, total: 0, rank: 1, isUser: true, winRate: 0 });

      const userRankIdx = globalRank.findIndex(r => r.isUser);
      this.setData({
        globalRank: globalRank.slice(0, 50),
        regionRank: regionRank.slice(0, 50),
        levelRank: levelRank.slice(0, 50),
        battleRank,
        userRank: userRankIdx >= 0 ? userRankIdx + 1 : '-'
      });
    } catch (e) {
      console.error('加载排行榜失败:', e);
    }
  },

  generateMockRanks() {
    const names = [
      '攸县小王子', '碰胡高手', '字牌达人', '跑胡子迷', '攸县老铁',
      '牌神在世', '字牌小白', '碰胡新手', '攸县靓仔', '胡牌大神',
      '牌桌风云', '攸县跑胡子', '字牌小将', '碰碰胡', '攸县大侠',
      '牌坛新秀', '攸县碰胡王', '字牌天才', '跑胡小王子', '攸县第一'
    ];
    const regionNames = REGIONS.map(r => r.name);
    return names.map((name, idx) => ({
      name,
      region: regionNames[idx % regionNames.length],
      score: Math.floor(Math.random() * 5000) + 500,
      level: Math.floor(Math.random() * 50) + 1
    }));
  }
});
