const app = getApp();
const { createDeck, shuffle, deal, groupCards, canHu, aiSelectCard, aiShouldAction, detectPeng, detectChi, XIAOXIE, DAXIE } = require('../../utils/card-engine');

Page({
  data: {
    gameStarted: false,
    gamePhase: 'ready',  // ready / playing / ended
    difficulty: 1,       // 1简单 2中等 3困难
    difficultyNames: ['简单', '中等', '困难'],

    // 牌局状态
    playerHand: [],
    aiHand: [],
    pile: [],
    discardPile: [],
    lastDiscard: null,

    // 玩家操作状态
    selectedIdx: -1,
    canPeng: false,
    canChi: false,
    canHu: false,
    showActions: false,

    // 分数
    playerScore: 0,
    aiScore: 0,
    playerMelds: [],
    aiMelds: [],

    // 消息
    message: '选择难度开始对战',
    gameLog: [],

    // AI思考
    aiThinking: false,
    showLog: false,
    pendingCard: null
  },

  onLoad() {},

  onDifficultyChange(e) {
    this.setData({ difficulty: parseInt(e.currentTarget.dataset.level) });
  },

  onStartGame() {
    const { zhuang, player2, pile } = deal();
    // 玩家拿庄家的牌，AI拿player2
    this.setData({
      gameStarted: true,
      gamePhase: 'playing',
      playerHand: this.sortHand(zhuang),
      aiHand: player2,
      pile: pile,
      discardPile: [],
      lastDiscard: null,
      selectedIdx: -1,
      playerScore: 0,
      aiScore: 0,
      playerMelds: [],
      aiMelds: [],
      message: '你的回合，选择要打出的牌',
      gameLog: ['牌局开始！你是庄家，先出牌。']
    });
  },

  sortHand(hand) {
    return [...hand].sort((a, b) => {
      if (a.type !== b.type) return a.type === 'xiaoxie' ? -1 : 1;
      return a.value - b.value;
    });
  },

  onCardTap(e) {
    if (this.data.gamePhase !== 'playing' || this.data.aiThinking) return;
    const idx = e.currentTarget.dataset.idx;
    this.setData({ selectedIdx: this.data.selectedIdx === idx ? -1 : idx });
  },

  onDiscard() {
    if (this.data.selectedIdx < 0) {
      wx.showToast({ title: '请选择一张牌打出', icon: 'none' });
      return;
    }
    const idx = this.data.selectedIdx;
    const card = this.data.playerHand[idx];
    const newHand = [...this.data.playerHand];
    newHand.splice(idx, 1);

    const log = [...this.data.gameLog, `你打出：${card.name}`];

    this.setData({
      playerHand: this.sortHand(newHand),
      selectedIdx: -1,
      lastDiscard: card,
      discardPile: [...this.data.discardPile, card],
      gameLog: log
    });

    // 检查AI是否碰/吃/胡
    setTimeout(() => this.aiRespond(card), 800);
  },

  aiRespond(card) {
    const aiHand = [...this.data.aiHand];
    const action = aiShouldAction(aiHand, card);
    const log = [...this.data.gameLog];

    if (action && action.action === 'hu') {
      // AI胡了
      this.data.aiMelds.push({ type: 'hu', name: '胡牌', score: 10 });
      log.push(`🤖 AI胡了！${card.name}`);
      this.setData({
        aiScore: this.data.aiScore + 10,
        aiMelds: this.data.aiMelds,
        gamePhase: 'ended',
        message: 'AI胡牌，你输了！',
        gameLog: log
      });
      this.saveBattleResult(false);
      return;
    }

    if (action && action.action === 'peng') {
      // AI碰
      const pengCards = aiHand.filter(c => c.name === card.name && c.type === card.type).slice(0, 2);
      const newAiHand = aiHand.filter(c => !pengCards.includes(c));
      pengCards.push(card);
      this.data.aiMelds.push({ type: 'peng', name: card.name, score: 1 });
      log.push(`🤖 AI碰了 ${card.name}`);
      this.setData({
        aiHand: newAiHand,
        aiScore: this.data.aiScore + 1,
        aiMelds: this.data.aiMelds,
        gameLog: log
      });
      // AI碰后出牌
      setTimeout(() => this.aiPlay(), 1000);
      return;
    }

    if (action && action.action === 'chi') {
      // AI吃
      log.push(`🤖 AI吃了 ${card.name}`);
      this.setData({ gameLog: log });
      // 简化处理：AI吃后出牌
      setTimeout(() => this.aiPlay(), 1000);
      return;
    }

    // AI不要，摸牌
    this.aiDrawAndPlay();
  },

  aiDrawAndPlay() {
    const pile = [...this.data.pile];
    if (pile.length === 0) {
      this.endGame('draw');
      return;
    }
    const drawn = pile.shift();
    const aiHand = [...this.data.aiHand, drawn];
    const log = [...this.data.gameLog, '🤖 AI摸牌'];

    // 检查AI是否胡
    if (canHu(aiHand)) {
      this.data.aiMelds.push({ type: 'hu', name: '自摸胡', score: 15 });
      log.push('🤖 AI自摸胡！');
      this.setData({
        aiScore: this.data.aiScore + 15,
        aiMelds: this.data.aiMelds,
        gamePhase: 'ended',
        message: 'AI自摸胡，你输了！',
        gameLog: log,
        pile
      });
      this.saveBattleResult(false);
      return;
    }

    // AI出牌
    const discard = aiSelectCard(aiHand, null);
    const newAiHand = aiHand.filter(c => c !== discard);
    log.push(`🤖 AI打出：${discard.name}`);

    this.setData({
      aiHand: newAiHand,
      pile,
      lastDiscard: discard,
      discardPile: [...this.data.discardPile, discard],
      message: '你的回合',
      gameLog: log,
      aiThinking: false
    });

    // 检查玩家是否碰/胡
    this.checkPlayerAction(discard);
  },

  aiPlay() {
    const aiHand = [...this.data.aiHand];
    if (aiHand.length === 0) {
      this.endGame('draw');
      return;
    }
    const discard = aiSelectCard(aiHand, null);
    const newAiHand = aiHand.filter(c => c !== discard);
    const log = [...this.data.gameLog, `🤖 AI打出：${discard.name}`];

    this.setData({
      aiHand: newAiHand,
      lastDiscard: discard,
      discardPile: [...this.data.discardPile, discard],
      message: '你的回合',
      gameLog: log
    });

    this.checkPlayerAction(discard);
  },

  checkPlayerAction(card) {
    const hand = this.data.playerHand;
    const canPeng = hand.filter(c => c.name === card.name && c.type === card.type).length >= 2;
    const testHand = [...hand, card];
    const canHuResult = canHu(testHand);

    if (canPeng || canHuResult) {
      this.setData({
        canPeng,
        canHu: canHuResult,
        showActions: true,
        pendingCard: card
      });
    }
  },

  onActionPeng() {
    const card = this.data.pendingCard;
    const hand = [...this.data.playerHand];
    const pengCards = hand.filter(c => c.name === card.name && c.type === card.type).slice(0, 2);
    const newHand = hand.filter(c => !pengCards.includes(c));

    this.data.playerMelds.push({ type: 'peng', name: card.name, score: 1 });
    const log = [...this.data.gameLog, `你碰了 ${card.name}`];

    this.setData({
      playerHand: this.sortHand(newHand),
      playerScore: this.data.playerScore + 1,
      playerMelds: this.data.playerMelds,
      showActions: false,
      canPeng: false,
      canHu: false,
      selectedIdx: -1,
      message: '碰成功！选择要打出的牌',
      gameLog: log
    });
  },

  onActionHu() {
    const card = this.data.pendingCard;
    const hand = [...this.data.playerHand, card];
    this.data.playerMelds.push({ type: 'hu', name: '胡牌', score: 10 });
    const log = [...this.data.gameLog, `你胡了！${card.name}`];

    this.setData({
      playerHand: this.sortHand(hand),
      playerScore: this.data.playerScore + 10,
      playerMelds: this.data.playerMelds,
      showActions: false,
      gamePhase: 'ended',
      message: '恭喜你胡牌了！',
      gameLog: log
    });
    this.saveBattleResult(true);
  },

  onActionPass() {
    this.setData({ showActions: false, canPeng: false, canHu: false });
    // 玩家不要，轮到玩家摸牌出牌
    this.playerDraw();
  },

  playerDraw() {
    const pile = [...this.data.pile];
    if (pile.length === 0) {
      this.endGame('draw');
      return;
    }
    const drawn = pile.shift();
    const hand = [...this.data.playerHand, drawn];
    const log = [...this.data.gameLog, `你摸到：${drawn.name}`];

    // 检查自摸胡
    if (canHu(hand)) {
      this.data.playerMelds.push({ type: 'hu', name: '自摸胡', score: 15 });
      log.push('你自摸胡了！');
      this.setData({
        playerHand: this.sortHand(hand),
        playerScore: this.data.playerScore + 15,
        playerMelds: this.data.playerMelds,
        pile,
        gamePhase: 'ended',
        message: '恭喜自摸胡牌！',
        gameLog: log
      });
      this.saveBattleResult(true);
      return;
    }

    this.setData({
      playerHand: this.sortHand(hand),
      pile,
      message: '选择要打出的牌',
      gameLog: log
    });
  },

  endGame(reason) {
    const log = [...this.data.gameLog];
    if (reason === 'draw') {
      log.push('牌摸完了，平局！');
      this.setData({ message: '平局！', gamePhase: 'ended', gameLog: log });
    }
  },

  saveBattleResult(playerWin) {
    try {
      const history = wx.getStorageSync('battle_history') || [];
      history.push({
        difficulty: this.data.difficulty,
        playerScore: this.data.playerScore,
        aiScore: this.data.aiScore,
        result: playerWin ? 'win' : 'lose',
        date: new Date().toISOString()
      });
      wx.setStorageSync('battle_history', history);

      if (playerWin) {
        app.globalData.totalScore += this.data.playerScore + 20;
      } else {
        app.globalData.totalScore += this.data.playerScore;
      }
      app.saveLocalData();
    } catch (e) {}
  },

  toggleLog() {
    this.setData({ showLog: !this.data.showLog });
  },

  onRestart() {
    this.onStartGame();
  },

  onBack() {
    wx.navigateBack();
  }
});
