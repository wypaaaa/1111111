const app = getApp();

Page({
  data: {
    totalScore: 0,
    currentLevel: 1,
    regionName: '未选择',
    quizStats: { total: 0, correct: 0, bestCombo: 0 },
    battleStats: { total: 0, wins: 0, score: 0 },
    endgameCompleted: 0,
    menuItems: [
      { id: 'region', title: '修改地区', icon: '📍', desc: '' },
      { id: 'history', title: '答题记录', icon: '📊', desc: '查看历史成绩' },
      { id: 'reset', title: '重置数据', icon: '🔄', desc: '清除所有数据' },
      { id: 'about', title: '关于', icon: 'ℹ️', desc: '攸县碰胡学堂 v1.0' }
    ]
  },

  onLoad() {
    this.loadData();
  },

  onShow() {
    this.loadData();
  },

  loadData() {
    const region = app.globalData.region;
    let quizStats = { total: 0, correct: 0, bestCombo: 0 };
    let battleStats = { total: 0, wins: 0, score: 0 };
    let endgameCompleted = 0;

    try {
      const history = wx.getStorageSync('quiz_history') || [];
      history.forEach(h => {
        quizStats.total += h.total || 10;
        quizStats.correct += h.correctCount || 0;
        quizStats.bestCombo = Math.max(quizStats.bestCombo, h.maxCombo || 0);
      });

      const battles = wx.getStorageSync('battle_history') || [];
      battles.forEach(b => {
        battleStats.total += 1;
        battleStats.wins += b.result === 'win' ? 1 : 0;
        battleStats.score += b.playerScore || 0;
      });

      const completed = wx.getStorageSync('endgame_completed') || [];
      endgameCompleted = completed.length;
    } catch (e) {}

    const quizAccuracy = quizStats.total > 0 ? Math.round(quizStats.correct / quizStats.total * 100) : 0;
    const battleWinRate = battleStats.total > 0 ? Math.round(battleStats.wins / battleStats.total * 100) : 0;

    this.setData({
      totalScore: app.globalData.totalScore,
      currentLevel: app.globalData.currentLevel,
      regionName: region ? region.fullName : '未选择',
      quizStats,
      battleStats,
      endgameCompleted,
      quizAccuracy,
      battleWinRate
    });
  },

  onMenuTap(e) {
    const id = e.currentTarget.dataset.id;
    if (id === 'region') {
      wx.navigateTo({ url: '/pages/region-select/region-select' });
    } else if (id === 'history') {
      this.showHistory();
    } else if (id === 'reset') {
      this.resetData();
    } else if (id === 'about') {
      this.showAbout();
    }
  },

  showHistory() {
    try {
      const history = wx.getStorageSync('quiz_history') || [];
      if (history.length === 0) {
        wx.showToast({ title: '暂无答题记录', icon: 'none' });
        return;
      }
      const recent = history.slice(-5).reverse();
      let msg = '最近5次答题：\n';
      recent.forEach((h, idx) => {
        const date = new Date(h.date).toLocaleDateString();
        msg += `${date} 第${h.level}关 ${h.correctCount}/${h.total} +${h.score}分\n`;
      });
      wx.showModal({ title: '答题记录', content: msg, showCancel: false });
    } catch (e) {
      wx.showToast({ title: '读取失败', icon: 'none' });
    }
  },

  resetData() {
    wx.showModal({
      title: '确认重置',
      content: '将清除所有积分、关卡进度和记录，确定吗？',
      success: (res) => {
        if (res.confirm) {
          app.globalData.totalScore = 0;
          app.globalData.currentLevel = 1;
          app.globalData.region = null;
          app.saveLocalData();
          try {
            wx.removeStorageSync('quiz_history');
            wx.removeStorageSync('battle_history');
            wx.removeStorageSync('endgame_completed');
            wx.removeStorageSync('user_data');
          } catch (e) {}
          this.loadData();
          wx.showToast({ title: '已重置', icon: 'none' });
        }
      }
    });
  },

  showAbout() {
    wx.showModal({
      title: '关于攸县碰胡学堂',
      content: '一款帮助攸县人学牌、练牌的微信小程序。\n\n功能：\n· 学牌入门\n· 1000道闯关题\n· 残局挑战\n· 人机大战\n· 地区排行榜\n\n版本：v1.0',
      showCancel: false
    });
  }
});
