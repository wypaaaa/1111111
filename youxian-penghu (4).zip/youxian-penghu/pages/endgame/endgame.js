const app = getApp();
const { ENDGAME_PUZZLES } = require('../../utils/questions');

Page({
  data: {
    puzzles: ENDGAME_PUZZLES,
    currentPuzzle: null,
    showPuzzle: false,
    showHint: false,
    showSolution: false,
    userAnswer: '',
    completedPuzzles: [],
    selectedCards: []
  },

  onLoad() {
    this.loadCompleted();
  },

  loadCompleted() {
    try {
      const completed = wx.getStorageSync('endgame_completed') || [];
      const puzzles = this.data.puzzles.map(p => ({
        ...p,
        completed: completed.includes(p.level)
      }));
      this.setData({ completedPuzzles: completed, puzzles });
    } catch (e) {}
  },

  onPuzzleTap(e) {
    const level = e.currentTarget.dataset.level;
    const puzzle = this.data.puzzles.find(p => p.level === level);
    if (puzzle) {
      this.setData({
        currentPuzzle: puzzle,
        showPuzzle: true,
        showHint: false,
        showSolution: false,
        selectedCards: []
      });
    }
  },

  onCardSelect(e) {
    const card = e.currentTarget.dataset.card;
    let selected = [...this.data.selectedCards];
    const idx = selected.indexOf(card);
    if (idx >= 0) {
      selected.splice(idx, 1);
    } else {
      selected.push(card);
    }
    this.setData({ selectedCards: selected });
  },

  onShowHint() {
    this.setData({ showHint: true });
  },

  onShowSolution() {
    this.setData({ showSolution: true });
    // 标记完成
    const completed = [...this.data.completedPuzzles];
    const level = this.data.currentPuzzle.level;
    if (!completed.includes(level)) {
      completed.push(level);
      const puzzles = this.data.puzzles.map(p => ({
        ...p,
        completed: p.level === level ? true : p.completed
      }));
      this.setData({ completedPuzzles: completed, puzzles });
      try {
        wx.setStorageSync('endgame_completed', completed);
      } catch (e) {}

      // 加积分
      app.globalData.totalScore += this.data.currentPuzzle.score;
      app.saveLocalData();
    }
  },

  onClosePuzzle() {
    this.setData({ showPuzzle: false, currentPuzzle: null });
  },

  isCompleted(level) {
    return this.data.completedPuzzles.includes(level);
  }
});
