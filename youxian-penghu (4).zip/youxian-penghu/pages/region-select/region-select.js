const app = getApp();
const { REGIONS, searchRegions } = require('../../utils/regions');

Page({
  data: {
    regions: [],
    searchResult: [],
    keyword: '',
    selectedRegion: null,
    selectedVillage: '',
    showVillages: false,
    currentRegion: null,
    regionTypes: { '街道': [], '镇': [], '乡': [] },
    showType: '街道'
  },

  onLoad() {
    this.groupRegions();
  },

  groupRegions() {
    const types = { '街道': [], '镇': [], '乡': [] };
    REGIONS.forEach(r => {
      if (types[r.type]) types[r.type].push(r);
    });
    this.setData({
      regionTypes: types,
      regions: REGIONS,
      currentList: types[this.data.showType]
    });
  },

  onShowTypeChange(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({
      showType: type,
      currentList: this.data.regionTypes[type]
    });
  },

  onRegionTap(e) {
    const name = e.currentTarget.dataset.name;
    const region = REGIONS.find(r => r.name === name);
    if (region) {
      this.setData({
        currentRegion: region,
        showVillages: true
      });
    }
  },

  onVillageTap(e) {
    const village = e.currentTarget.dataset.village;
    const region = this.data.currentRegion;
    this.setData({
      selectedRegion: region,
      selectedVillage: village
    });

    // 保存选择
    const regionData = {
      regionName: region.name,
      village: village,
      fullName: `${region.name} ${village}`
    };
    app.globalData.region = regionData;
    app.saveLocalData();

    wx.showToast({
      title: `已选择：${region.name}`,
      icon: 'none',
      success: () => {
        setTimeout(() => wx.navigateBack(), 1500);
      }
    });
  },

  onSearch(e) {
    const keyword = e.detail.value.trim();
    this.setData({ keyword });
    if (keyword.length === 0) {
      this.setData({ searchResult: [] });
      return;
    }
    const results = searchRegions(keyword);
    this.setData({ searchResult: results });
  },

  onSearchResultTap(e) {
    const { type, name, region } = e.currentTarget.dataset;
    if (type === 'region') {
      this.onRegionTap({ currentTarget: { dataset: { name } } });
    } else {
      const regionObj = REGIONS.find(r => r.name === region);
      if (regionObj) {
        this.setData({
          currentRegion: regionObj,
          showVillages: true,
          selectedRegion: regionObj,
          selectedVillage: name
        });
        const regionData = {
          regionName: region,
          village: name,
          fullName: `${region} ${name}`
        };
        app.globalData.region = regionData;
        app.saveLocalData();
        wx.showToast({
          title: `已选择：${region}`,
          icon: 'none',
          success: () => setTimeout(() => wx.navigateBack(), 1500)
        });
      }
    }
  },

  onCloseVillages() {
    this.setData({ showVillages: false, currentRegion: null });
  }
});
