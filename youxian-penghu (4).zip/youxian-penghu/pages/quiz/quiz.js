const app = getApp();
const { getQuestionsForLevel } = require('../../utils/questions');

Page({
  data: {
    level: 1,
    questions: [],
    currentIndex: 0,
    currentQuestion: null,
    selectedAnswer: -1,
    isAnswered: false,
    isCorrect: false,
    score: 0,
    correctCount: 0,
    totalCount: 10,
    showResult: false,
    progress: 0,
    timeLeft: 30,
    timer: null,
    combo: 0,
    maxCombo: 0
  },

  onLoad(options) {
    const level = parseInt(options.level) || app.globalData.currentLevel || 1;
    this.setData({ level });
    this.loadQuestions(level);
  },

  onUnload() {
    if (this.data.timer) clearInterval(this.data.timer);
  },

  loadQuestions(level) {
    const questions = getQuestionsForLevel(level, 10);
    this.setData({
      questions,
      currentIndex: 0,
      currentQuestion: questions[0],
      selectedAnswer: -1,
      isAnswered: false,
      score: 0,
      correctCount: 0,
      showResult: false,
      progress: 0,
      combo: 0,
      maxCombo: 0
    });
    this.startTimer();
  },

  startTimer() {
    if (this.data.timer) clearInterval(this.data.timer);
    this.setData({ timeLeft: 30 });
    const timer = setInterval(() => {
      if (this.data.timeLeft <= 1) {
        clearInterval(timer);
        this.onTimeout();
      } else {
        this.setData({ timeLeft: this.data.timeLeft - 1 });
      }
    }, 1000);
    this.setData({ timer });
  },

  onTimeout() {
    if (!this.data.isAnswered) {
      this.setData({
        isAnswered: true,
        isCorrect: false,
        selectedAnswer: -1,
        combo: 0
      });
      wx.showToast({ title: '时间到！', icon: 'none' });
      setTimeout(() => this.nextQuestion(), 2000);
    }
  },

  onOptionTap(e) {
    if (this.data.isAnswered) return;
    const idx = e.currentTarget.dataset.idx;
    const correct = idx === this.data.currentQuestion.answer;
    const combo = correct ? this.data.combo + 1 : 0;
    const maxCombo = Math.max(combo, this.data.maxCombo);
    const addScore = correct ? (10 + combo * 2) : 0;

    this.setData({
      selectedAnswer: idx,
      isAnswered: true,
      isCorrect: correct,
      score: this.data.score + addScore,
      correctCount: this.data.correctCount + (correct ? 1 : 0),
      combo,
      maxCombo
    });

    if (this.data.timer) clearInterval(this.data.timer);

    if (correct) {
      wx.showToast({ title: combo > 1 ? `${combo}连击！` : '正确！', icon: 'none' });
    } else {
      wx.showToast({ title: '答错了', icon: 'none' });
    }

    setTimeout(() => this.nextQuestion(), 1500);
  },

  nextQuestion() {
    const nextIdx = this.data.currentIndex + 1;
    if (nextIdx >= this.data.questions.length) {
      this.finishQuiz();
      return;
    }
    this.setData({
      currentIndex: nextIdx,
      currentQuestion: this.data.questions[nextIdx],
      selectedAnswer: -1,
      isAnswered: false,
      progress: Math.round((nextIdx / this.data.questions.length) * 100)
    });
    this.startTimer();
  },

  finishQuiz() {
    if (this.data.timer) clearInterval(this.data.timer);
    const { score, correctCount, level } = this.data;

    // 更新全局积分
    app.globalData.totalScore += score;
    if (correctCount >= 7) {
      app.globalData.currentLevel = level + 1;
    }
    app.saveLocalData();

    this.setData({
      showResult: true,
      progress: 100
    });

    // 保存成绩到本地
    try {
      const history = wx.getStorageSync('quiz_history') || [];
      history.push({
        level,
        score,
        correctCount,
        total: this.data.questions.length,
        maxCombo: this.data.maxCombo,
        date: new Date().toISOString()
      });
      wx.setStorageSync('quiz_history', history);
    } catch (e) {
      console.error('保存成绩失败:', e);
    }
  },

  onNextLevel() {
    const nextLevel = this.data.level + 1;
    this.setData({ level: nextLevel });
    this.loadQuestions(nextLevel);
  },

  onRetry() {
    this.loadQuestions(this.data.level);
  },

  onBack() {
    wx.navigateBack();
  }
});
