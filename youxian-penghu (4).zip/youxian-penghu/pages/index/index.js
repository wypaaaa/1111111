const app = getApp();
const { REGIONS } = require('../../utils/regions');

Page({
  data: {
    hasRegion: false,
    regionName: '',
    totalScore: 0,
    currentLevel: 1,
    menuItems: [
      { id: 'study', title: '学牌入门', desc: '认识字牌，学习规则', icon: '📖', color: '#4CAF50' },
      { id: 'quiz', title: '闯关答题', desc: '1000道题等你挑战', icon: '🏆', color: '#FF9800' },
      { id: 'endgame', title: '残局挑战', desc: '牌局残局实战演练', icon: '🎯', color: '#E91E63' },
      { id: 'battle', title: '人机大战', desc: 'AI对手等你来战', icon: '🤖', color: '#2196F3' },
      { id: 'leaderboard', title: '排行榜', desc: '看看谁是高手', icon: '🏅', color: '#9C27B0' },
      { id: 'profile', title: '个人中心', desc: '我的成绩和设置', icon: '👤', color: '#607D8B' }
    ],
    dailyTip: '',
    tips: [
      '碰胡中"碰"需要3张相同牌，"跑"需要4张',
      '小写和大写字牌不能混用哦',
      '吃牌只能吃上家打出的牌',
      '偎是手中的暗3张，比碰分数更高',
      '接近胡牌时要保守打法，减少失分',
      '保留相邻的牌，更容易组成顺子',
      '对手打什么牌，说明他不需要什么牌型',
      '跑和提都是6分，是最高分的牌型'
    ]
  },

  onLoad() {
    this.loadUserData();
    this.setDailyTip();
  },

  onShow() {
    this.loadUserData();
  },

  loadUserData() {
    const region = app.globalData.region;
    this.setData({
      hasRegion: !!region,
      regionName: region ? region.fullName : '',
      totalScore: app.globalData.totalScore,
      currentLevel: app.globalData.currentLevel
    });
  },

  setDailyTip() {
    const dayIdx = new Date().getDay();
    this.setData({ dailyTip: this.data.tips[dayIdx % this.data.tips.length] });
  },

  onMenuTap(e) {
    const { id } = e.currentTarget.dataset;
    if (id === 'study') {
      wx.navigateTo({ url: '/pages/study/study' });
    } else if (id === 'quiz') {
      wx.navigateTo({ url: '/pages/quiz/quiz' });
    } else if (id === 'endgame') {
      wx.navigateTo({ url: '/pages/endgame/endgame' });
    } else if (id === 'battle') {
      wx.navigateTo({ url: '/pages/battle/battle' });
    } else if (id === 'leaderboard') {
      wx.switchTab({ url: '/pages/leaderboard/leaderboard' });
    } else if (id === 'profile') {
      wx.switchTab({ url: '/pages/profile/profile' });
    }
  },

  onSelectRegion() {
    wx.navigateTo({ url: '/pages/region-select/region-select' });
  }
});
