const { XIAOXIE, DAXIE } = require('../../utils/card-engine');

Page({
  data: {
    currentTab: 0,
    tabs: ['认识字牌', '基本规则', '牌型详解', '计分规则'],
    xiaoxie: XIAOXIE,
    daxie: DAXIE,
    selectedCard: null,
    rules: [
      { title: '游戏人数', content: '4人游戏，各自为战' },
      { title: '使用牌数', content: '小写一到十各4张 + 大写壹到拾各4张 = 共80张' },
      { title: '发牌规则', content: '庄家15张，其余各14张，墩上留23张' },
      { title: '出牌顺序', content: '逆时针方向，庄家先出' },
      { title: '基本操作', content: '摸牌 → 出牌 → 碰/吃/胡 → 下一家' }
    ],
    meldTypes: [
      { name: '碰', desc: '3张完全相同的牌', score: 1, icon: '🀄', example: '一 一 一' },
      { name: '跑', desc: '4张完全相同的牌(明)', score: 6, icon: '🎴', example: '壹 壹 壹 壹' },
      { name: '偎', desc: '手中暗3张相同牌', score: 3, icon: '🔒', example: '三 三 三(暗牌)' },
      { name: '提', desc: '手中暗4张相同牌', score: 6, icon: '💎', example: '肆 肆 肆 肆(暗牌)' },
      { name: '吃', desc: '同字型连续3张牌', score: 0, icon: '🔗', example: '五 六 七' },
      { name: '胡', desc: '满足胡牌条件', score: '看牌型', icon: '🏆', example: '面子组+1对将' }
    ],
    scoringRules: [
      { name: '碰', score: 1, note: '3张同牌' },
      { name: '跑', score: 6, note: '4张同牌(明)' },
      { name: '偎', score: 3, note: '暗3张同牌' },
      { name: '提', score: 6, note: '暗4张同牌' },
      { name: '吃', score: 0, note: '不计分' },
      { name: '胡', score: '基础+附加', note: '根据牌型' }
    ]
  },

  onTabChange(e) {
    this.setData({ currentTab: e.currentTarget.dataset.idx });
  },

  onCardTap(e) {
    const { name, type } = e.currentTarget.dataset;
    this.setData({
      selectedCard: { name, type }
    });
    wx.showToast({ title: `${name}(${type === 'xiaoxie' ? '小写' : '大写'})`, icon: 'none' });
  }
});
