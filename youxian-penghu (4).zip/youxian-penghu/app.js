App({
  globalData: {
    userInfo: null,
    openid: '',
    region: null,        // 用户选择的村镇
    totalScore: 0,       // 总积分
    currentLevel: 1,     // 当前关卡
    battleMode: false,   // 人机对战模式
  },

  onLaunch() {
    // 初始化云开发
    if (wx.cloud) {
      wx.cloud.init({
        env: 'youxian-penghu-env', // 替换为实际云环境ID
        traceUser: true
      });
    }

    // 加载本地缓存数据
    this.loadLocalData();
  },

  loadLocalData() {
    try {
      const data = wx.getStorageSync('user_data');
      if (data) {
        this.globalData.totalScore = data.totalScore || 0;
        this.globalData.currentLevel = data.currentLevel || 1;
        this.globalData.region = data.region || null;
      }
    } catch (e) {
      console.error('加载本地数据失败:', e);
    }
  },

  saveLocalData() {
    try {
      wx.setStorageSync('user_data', {
        totalScore: this.globalData.totalScore,
        currentLevel: this.globalData.currentLevel,
        region: this.globalData.region
      });
    } catch (e) {
      console.error('保存本地数据失败:', e);
    }
  }
});
