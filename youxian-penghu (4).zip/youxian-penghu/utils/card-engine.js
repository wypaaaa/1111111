/**
 * 攸县碰胡 - 牌型引擎
 * 
 * 牌面：小写"一"~"十"各4张 + 大写"壹"~"拾"各4张 = 共80张
 * 
 * 基本规则：
 * - 4人游戏，庄家15张，其余14张，墩上留牌
 * - 碰(3张同牌)、跑(4张同牌)、煨(暗3张)、提(暗4张)
 * - 吃(顺子：同字型连续3张)
 * - 胡(满足胡牌条件)
 */

// ============ 牌面定义 ============
const XIAOXIE = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十'];
const DAXIE = ['壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖', '拾'];

// 生成一副完整的80张牌
function createDeck() {
  const deck = [];
  let id = 0;
  for (let i = 0; i < 4; i++) {
    XIAOXIE.forEach((name, idx) => {
      deck.push({ id: id++, name, type: 'xiaoxie', value: idx + 1, index: idx });
    });
    DAXIE.forEach((name, idx) => {
      deck.push({ id: id++, name, type: 'daxie', value: idx + 1, index: idx });
    });
  }
  return deck;
}

// 洗牌 (Fisher-Yates)
function shuffle(deck) {
  const arr = [...deck];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// 发牌
function deal() {
  const deck = shuffle(createDeck());
  return {
    zhuang: deck.slice(0, 15),    // 庄家15张
    player2: deck.slice(15, 29),  // 14张
    player3: deck.slice(29, 43),  // 14张
    player4: deck.slice(43, 57),  // 14张
    pile: deck.slice(57)          // 墩上23张
  };
}

// ============ 牌型判断 ============

// 按value+type分组
function groupCards(hand) {
  const groups = {};
  hand.forEach(card => {
    const key = `${card.type}_${card.value}`;
    if (!groups[key]) groups[key] = [];
    groups[key].push(card);
  });
  return groups;
}

// 检测碰(3张同牌)
function detectPeng(hand) {
  const groups = groupCards(hand);
  const pengs = [];
  for (const key in groups) {
    if (groups[key].length >= 3) {
      pengs.push({
        type: 'peng',
        cards: groups[key].slice(0, 3),
        name: groups[key][0].name,
        score: 1
      });
    }
  }
  return pengs;
}

// 检测跑(4张同牌)
function detectPao(hand) {
  const groups = groupCards(hand);
  const paos = [];
  for (const key in groups) {
    if (groups[key].length === 4) {
      paos.push({
        type: 'pao',
        cards: groups[key],
        name: groups[key][0].name,
        score: 6
      });
    }
  }
  return paos;
}

// 检测吃(顺子：同字型连续3张)
function detectChi(hand) {
  const chis = [];
  ['xiaoxie', 'daxie'].forEach(type => {
    const typeCards = hand.filter(c => c.type === type);
    const valueSet = {};
    typeCards.forEach(c => {
      if (!valueSet[c.value]) valueSet[c.value] = [];
      valueSet[c.value].push(c);
    });
    for (let v = 1; v <= 8; v++) {
      if (valueSet[v] && valueSet[v + 1] && valueSet[v + 2]) {
        chis.push({
          type: 'chi',
          cards: [valueSet[v][0], valueSet[v + 1][0], valueSet[v + 2][0]],
          name: `${valueSet[v][0].name}${valueSet[v + 1][0].name}${valueSet[v + 2][0].name}`,
          score: 0
        });
      }
    }
  });
  return chis;
}

// 检测偎(暗3张 - 手中有3张同牌未碰)
function detectWei(hand) {
  const groups = groupCards(hand);
  const weis = [];
  for (const key in groups) {
    if (groups[key].length === 3) {
      weis.push({
        type: 'wei',
        cards: groups[key],
        name: groups[key][0].name,
        score: 3
      });
    }
  }
  return weis;
}

// 检测提(暗4张)
function detectTi(hand) {
  const groups = groupCards(hand);
  const tis = [];
  for (const key in groups) {
    if (groups[key].length === 4) {
      tis.push({
        type: 'ti',
        cards: groups[key],
        name: groups[key][0].name,
        score: 6
      });
    }
  }
  return tis;
}

// ============ 胡牌检测 ============

// 判断是否能胡牌
function canHu(hand) {
  // 基本胡：手中牌能全部组成 碰/吃/将(2张同牌)
  // 攸县碰胡胡牌需要：若干组(碰/吃) + 1对将
  const groups = groupCards(hand);
  const counts = {};
  hand.forEach(c => {
    const key = `${c.type}_${c.value}`;
    counts[key] = (counts[key] || 0) + 1;
  });

  // 尝试每种牌作为将
  for (const jiangKey in counts) {
    if (counts[jiangKey] >= 2) {
      const remaining = { ...counts };
      remaining[jiangKey] -= 2;
      if (remaining[jiangKey] === 0) delete remaining[jiangKey];
      if (canFormMelds(remaining)) {
        return true;
      }
    }
  }
  return false;
}

// 递归判断剩余牌能否全部组成面子(碰/吃)
function canFormMelds(counts) {
  const keys = Object.keys(counts).filter(k => counts[k] > 0);
  if (keys.length === 0) return true;

  const firstKey = keys[0];

  // 尝试碰
  if (counts[firstKey] >= 3) {
    counts[firstKey] -= 3;
    if (counts[firstKey] === 0) delete counts[firstKey];
    if (canFormMelds(counts)) {
      counts[firstKey] = (counts[firstKey] || 0) + 3;
      return true;
    }
    counts[firstKey] = (counts[firstKey] || 0) + 3;
  }

  // 尝试吃
  const [type, valStr] = firstKey.split('_');
  const val = parseInt(valStr);
  if (val <= 8) {
    const k1 = firstKey;
    const k2 = `${type}_${val + 1}`;
    const k3 = `${type}_${val + 2}`;
    if ((counts[k1] || 0) > 0 && (counts[k2] || 0) > 0 && (counts[k3] || 0) > 0) {
      counts[k1]--; if (counts[k1] === 0) delete counts[k1];
      counts[k2]--; if (counts[k2] === 0) delete counts[k2];
      counts[k3]--; if (counts[k3] === 0) delete counts[k3];
      if (canFormMelds(counts)) {
        counts[k1] = (counts[k1] || 0) + 1;
        counts[k2] = (counts[k2] || 0) + 1;
        counts[k3] = (counts[k3] || 0) + 1;
        return true;
      }
      counts[k1] = (counts[k1] || 0) + 1;
      counts[k2] = (counts[k2] || 0) + 1;
      counts[k3] = (counts[k3] || 0) + 1;
    }
  }

  return false;
}

// ============ 计分 ============
function calculateScore(melds) {
  let score = 0;
  const details = [];
  melds.forEach(m => {
    score += m.score;
    if (m.score > 0) {
      details.push(`${m.name}(${m.type === 'peng' ? '碰' : m.type === 'pao' ? '跑' : m.type === 'wei' ? '偎' : '提'}): ${m.score}分`);
    }
  });
  return { score, details };
}

// ============ AI出牌 ============
function aiSelectCard(hand, lastCard) {
  // 简单AI：优先出不成对的单张，保留对子和可能的顺子
  const groups = groupCards(hand);
  const singles = [];
  const pairs = [];

  for (const key in groups) {
    if (groups[key].length === 1) singles.push(groups[key][0]);
    else if (groups[key].length === 2) pairs.push(groups[key][0]);
  }

  // 先出单张中离顺子最远的（边缘牌优先出）
  if (singles.length > 0) {
    singles.sort((a, b) => {
      const aDist = Math.min(a.value - 1, 10 - a.value);
      const bDist = Math.min(b.value - 1, 10 - b.value);
      return bDist - aDist;  // 距离边缘越远的优先出（远离顺子）
    });
    return singles[0];
  }

  // 再出对子
  if (pairs.length > 0) return pairs[0];

  // 最后随机出
  return hand[Math.floor(Math.random() * hand.length)];
}

// 判断AI是否碰/吃/胡
function aiShouldAction(hand, card) {
  // 检查碰
  const sameCount = hand.filter(c => c.name === card.name && c.type === card.type).length;
  if (sameCount >= 2) return { action: 'peng', card };

  // 检查吃
  const typeCards = hand.filter(c => c.type === card.type);
  const hasLeft = typeCards.some(c => c.value === card.value - 1);
  const hasRight = typeCards.some(c => c.value === card.value + 1);
  const hasLeft2 = typeCards.some(c => c.value === card.value - 2);
  const hasRight2 = typeCards.some(c => c.value === card.value + 2);

  if (hasLeft && hasRight) return { action: 'chi', card };
  if (hasLeft && hasLeft2) return { action: 'chi', card };
  if (hasRight && hasRight2) return { action: 'chi', card };

  // 检查胡
  const testHand = [...hand, card];
  if (canHu(testHand)) return { action: 'hu', card };

  return null;
}

module.exports = {
  XIAOXIE, DAXIE,
  createDeck, shuffle, deal,
  groupCards,
  detectPeng, detectPao, detectChi, detectWei, detectTi,
  canHu, canFormMelds,
  calculateScore,
  aiSelectCard, aiShouldAction
};
